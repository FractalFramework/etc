## Overview

Converts Html into Connectors.

## Call

`conv::call(['txt'=>$txt]);`

## Functions

- repari($d)
- md2conn($d)
- tags($tag,$atb,$d)
- cleanhtml($d)
- cleanconn($d)
- ecart($v,$a,$b)
- recursearch($v,$ab,$ba,$tag)
- parse($v,$x='')
- call($p)
