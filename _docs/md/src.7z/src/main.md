## Overview

Main is the framework's central component.
Its architecture is such that the main page is built around content blocks, one of which, the `main`, is the target of all changes to the page.

The reader currently knows only one client, `index`, whose expected variables it associates with `blocks`.

## Functions

- read($a,$g)
- call($g)
