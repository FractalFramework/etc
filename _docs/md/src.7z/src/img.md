## Overview

Download images from web, [forms], and base64.
The image are renamed locally.
No backup of the original source id actually operated.
Build thumbnails of beggest files.
The images are located in `/img`.

## Functions

- b64img($u)
- imgthumb($f)
- getim($f,$w=240,$h=180)
- scale($w,$h,$wo,$ho,$s)
- thumb($in,$out,$w,$h,$s)
- alpha($img)
