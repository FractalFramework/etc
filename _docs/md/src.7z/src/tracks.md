## Overview

Standalone application for the commentaries.

## Functions

- del($p)
- edit($p)
- save($p)
- form($a)
- read($p)
- stream($p)
- call($p)
