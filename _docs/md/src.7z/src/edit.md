## Overview

Permet de produire des formulaires d'après les définitions des tables.

## Call

`edit::call(['a'=>$tablename,'b'=>'play'|'edit'|'create','c'=>$id]);`

## Functions

- save($p)
- update($p)
- create($p)
- form($p)
- play($p)
- list()
- eligibles($a,$b,$rid)
- menu($a,$c,$rid)
- read($p)
- call($p)
