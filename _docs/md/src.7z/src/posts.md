## Overview

Standalone application for the Posts.
The edition is on-place.
The upload is as fast as 'paste'.

## Functions

- catid($a)
- content($p)
- del($p)
- save($p)
- update($p)
- create($p)
- datas($p)
- read($p)
- stream($p)
- call($p)
