## Overview

It's a sum of useful builders

## Functions

- tabler($r,$head='',$keys='',$frame='')
- tabs($r,$id='tab1',$c='')
- playr($r,$c='',$o='')
- tree($r,$c='',$o='')
- mkli($r,$ul='ul')
- scroll($d,$max=10,$w='',$h='',$id='')
- writecsv($f,$r)
- readcsv($f)
- csvfile($f,$r,$t='')
