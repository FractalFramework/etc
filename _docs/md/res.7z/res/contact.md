## Overview

Module to display a form for contects.
It will use the table `contacts`.

## Functions

- save($p)
- read($p)
- call($p)
