## Overview

Application which references classes and functions, and their links, in two tables `_prog` and `_progr`.

It produces csv files for data-visualisation of the programme.
And it can produce the software's automatic documentation.

## Functions

- doc()
- iter2($ka)
- see2($p)
- iter($ka)
- see($p)
- vue()
- save2($r)
- unused($r,$rb)
- find($d,$fc)
- arbo($r)
- mktree($a,$b)
- funcsee($r)
- functree($r)
- save($p,$r)
- find_func($d,$fc)
- '.$fc.'(')
- funcnt($p,$r)
- funclist($r)
- count_cases($a,$va)
- occurrences($dr,$r)
- funcount($r)
- analys($d)
- ')!==false)$rf[]=between($v,'function ','(')
- capture($r,$dr='')
- rapport($r,$p)
- build($p)
- state($d)
- read($p)
- menu($p,$o)
- call($p)
