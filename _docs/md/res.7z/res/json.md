## Overview

Calls json definitions from the `public/json` directory (by default).
Used by some other libraries.
Let edit these files.

## Call

`json::call('cnfg/vars');`

## Functions

- add($p)
- save($p)
- edit($p)
- file($a)
- error()
- er($r,$a='')
- build($r)
- call($a)
