## Overview

Produce a formated form from definitions and array of values.

## Call

`form::call(['name'=>'var','age'=>'int'],['name'=>'bob','age'=>'18']);`

## Functions

- build($r)
- call($rp,$j='',$mode='')
