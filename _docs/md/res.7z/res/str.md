## Overview

Collection of filters for the strings.

## Functions

- acc($o=1)
- eradic_acc($d)
- normalize_alpha($d,$o='')
- normalize_ext($d)
- normalize($d,$o='')
- numentities($d)
- clean_acc($d)
- clean_punctuation($d,$o='')
- nicequotes($d,$o='')
- add_nbsp($d)
- mb_ucfirst($d,$e='utf-8')
- mb_uclet($d,$e='utf-8')
- lowcase($d)
- letcase($d)
- lowercase($d)
- clean_lines($d,$o='')
- delspc($d)
- clean_whitespaces($d)
- trim($d,$o='')
- clean_mail($d)
- clean_n($d)
- clean_br($d)
