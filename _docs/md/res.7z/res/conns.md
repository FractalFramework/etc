## Overview

Collection of sub-actions for Connectors.

## Call

`[:profile]`

## Functions

- bt($p)
- socialk($u,$d='')
- list($p,$o='')
- art($id,$t='')
- read($id,$o='')
- usrart($id)
- uid($a)
- profile($id,$o='')
- socials($id,$o='')
